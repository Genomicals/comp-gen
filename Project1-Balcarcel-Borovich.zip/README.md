# Computational Genomics
Project repository for our computational genomics course.

## License
This work is dual-licensed under GPL Version 2 and GPL Version 3. You may choose between these licenses on a case-by-case basis.

